# B.W. Study — rebuilt starter

A responsive bilingual (Hindi/English) learning platform starter with a polished dashboard, sample MCQ quiz, Firebase email/password auth, Firestore resources, private Storage uploads, progress tracking and owner-only publishing.

## Run it
1. Install Node.js 20+.
2. Create a Firebase project at https://console.firebase.google.com/.
3. Enable Authentication > Email/Password; create Firestore; enable Storage.
4. Copy `.env.example` to `.env.local` and fill in the Firebase web app values.
5. In a terminal in this folder, run:
   ```bash
   npm install
   npm run dev
   ```
6. Open the local URL Vite prints.

## Firebase security
Publish `firestore.rules` in Firestore > Rules and `storage.rules` in Storage > Rules. Never use open test rules in production.
To grant owner access, sign up first, copy the UID from Firebase Authentication, then on a trusted computer/server install `firebase-admin`, set `GOOGLE_APPLICATION_CREDENTIALS` to a service-account JSON path, and run:
```bash
node scripts/set-admin.mjs YOUR_USER_UID
```
The `scripts/set-admin.mjs` script must be created using the trusted server instructions in Firebase Admin SDK documentation before running. Never put service account keys in browser code or `.env.local`.

## Important
- Without Firebase configuration, the UI and sample quiz work in preview mode; accounts and cloud storage are disabled.
- Quiz content here is sample practice content. Replace it with content you own or are allowed to publish.
- This is a starter, not a finished production service. Add email verification, password reset, account deletion, privacy policy, terms, abuse reporting, and test security rules before public launch.
- Website deployment and Android packaging/signing are separate steps. This ZIP is not an APK.
