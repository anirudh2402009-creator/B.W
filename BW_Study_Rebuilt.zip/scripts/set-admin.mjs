import admin from "firebase-admin";
const uid = process.argv[2];
if (!uid) { console.error("Usage: node scripts/set-admin.mjs YOUR_USER_UID"); process.exit(1); }
admin.initializeApp({ credential: admin.credential.applicationDefault() });
const user = await admin.auth().getUser(uid);
await admin.auth().setCustomUserClaims(uid, { ...(user.customClaims || {}), admin: true });
console.log(`Admin claim set for ${uid}. Sign out and sign in again.`);
